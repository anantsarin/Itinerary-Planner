package DataTypes;

public class Business
{
	private int ID;
	private String BusinessID;
	private String Name;
	private String URL;
	private Double Rating;
	private int ReviewsCount;
	private String Phone;
	private String AddressLine1;
	private String AddressLine2;
	private City City;
	private State State;
	private Country Country;
	private PostalCode Postal_Code;
	private String ImageURL;
	private String RatingImgURL;
	private String RatingImgURLSmall;
	private String RatingImgURLLarge;
	private String Snippet;
	private String SnippetImageURL;

	
	public Business(int ID, String BusinessID, String Name, String URL, Double Rating, int ReviewsCount,
			String Phone, String AddressLine1, String AddressLine2, City City, State State,
			Country  Country, PostalCode Postal_Code, String ImageURL, String RatingImgURL,
			String RatingImgURLSmall, String RatingImgURLLarge, String Snippet, String SnippetImageURL)
	{
		setID(ID);
		setBusinessID(BusinessID);
		setName(Name);
		setURL(URL);
		setRating(Rating);
		setReviewsCount(ReviewsCount);
		setPhone(Phone);
		setAddressLine1(AddressLine1);
		setAddressLine2(AddressLine2);
		setCity(City);
		setState(State);
		setCountry(Country);
		setPostal_Code(Postal_Code);
		setImageURL(ImageURL);
		setRatingImgURL(RatingImgURL);
		setRatingImgURLSmall(RatingImgURLSmall);
		setRatingImgURLLarge(RatingImgURLLarge);
		setSnippet(Snippet);
		setSnippetImageURL(SnippetImageURL);
	}

	public int getID()
	{
		return ID;
	}

	public void setID(int iD)
	{
		ID = iD;
	}
	
	public String getBusinessID()
	{
		return BusinessID;
	}

	public void setBusinessID(String businessID)
	{
		BusinessID = businessID;
	}

	public String getName()
	{
		return Name;
	}

	public void setName(String name)
	{
		Name = name;
	}

	public String getURL()
	{
		return URL;
	}

	public void setURL(String URL)
	{
		this.URL = URL;
	}

	public Double getRating()
	{
		return Rating;
	}

	public void setRating(Double rating)
	{
		Rating = rating;
	}

	public int getReviewsCount()
	{
		return ReviewsCount;
	}

	public void setReviewsCount(int reviewsCount)
	{
		ReviewsCount = reviewsCount;
	}

	public String getPhone()
	{
		return Phone;
	}

	public void setPhone(String phone)
	{
		Phone = phone;
	}

	public String getAddressLine1()
	{
		return AddressLine1;
	}

	public void setAddressLine1(String addressLine1)
	{
		AddressLine1 = addressLine1;
	}

	public String getAddressLine2()
	{
		return AddressLine2;
	}

	public void setAddressLine2(String addressLine2)
	{
		AddressLine2 = addressLine2;
	}

	public City getCity()
	{
		return City;
	}

	public void setCity(City city)
	{
		City = city;
	}

	public State getState()
	{
		return State;
	}

	public void setState(State state)
	{
		State = state;
	}

	public Country getCountry()
	{
		return Country;
	}

	public void setCountry(Country country)
	{
		Country = country;
	}

	public PostalCode getPostal_Code()
	{
		return Postal_Code;
	}

	public void setPostal_Code(PostalCode postal_Code)
	{
		Postal_Code = postal_Code;
	}

	public String getImageURL()
	{
		return ImageURL;
	}

	public void setImageURL(String imageURL)
	{
		ImageURL = imageURL;
	}

	public String getRatingImgURL()
	{
		return RatingImgURL;
	}

	public void setRatingImgURL(String ratingImgURL)
	{
		RatingImgURL = ratingImgURL;
	}

	public String getRatingImgURLSmall()
	{
		return RatingImgURLSmall;
	}

	public void setRatingImgURLSmall(String ratingImgURLSmall)
	{
		RatingImgURLSmall = ratingImgURLSmall;
	}

	public String getRatingImgURLLarge()
	{
		return RatingImgURLLarge;
	}

	public void setRatingImgURLLarge(String ratingImgURLLarge)
	{
		RatingImgURLLarge = ratingImgURLLarge;
	}

	public String getSnippet()
	{
		return Snippet;
	}

	public void setSnippet(String snippet)
	{
		Snippet = snippet;
	}

	public String getSnippetImageURL()
	{
		return SnippetImageURL;
	}

	public void setSnippetImageURL(String snippetImageURL)
	{
		SnippetImageURL = snippetImageURL;
	}
}
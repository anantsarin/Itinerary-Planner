package pdp.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pdp.DataStructures.Business;
import pdp.DatabaseOperation.DatabaseOperations;

@WebServlet("/Driver")
public class Driver extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	public Driver()
	{
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		DatabaseOperations DO = new DatabaseOperations();
		
		request.setAttribute("tripResult", (boolean)false);
		request.setAttribute("states", DO.getStates());
		
		RequestDispatcher view = request.getRequestDispatcher("maps.jsp");
	    view.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		DatabaseOperations DO = new DatabaseOperations();
		
		String state = request.getParameter("selectState");
		String city = request.getParameter("selectCity");
		String datesFrom = request.getParameter("from");
		String datesTo = request.getParameter("to");
		String startEndPoint = request.getParameter("startEndPoint");
		String[] category = request.getParameterValues("category");
		String company = request.getParameter("company");
		
		request.setAttribute("selectedState", state);
		request.setAttribute("cities", DO.getCities(state));
		request.setAttribute("selectedFrom", datesFrom);
		request.setAttribute("selectedTo", datesTo);
		request.setAttribute("selectedCategory", category);
		request.setAttribute("selectedCompany", company);
		request.setAttribute("tripResult", (boolean)false);
		request.setAttribute("states", DO.getStates());
		request.setAttribute("startEndPoint", startEndPoint);
		
		if(city != "" && city != null)
		{
			request.setAttribute("selectedCity", city);
			
			String region = city + ", " + state;
			
			String start = startEndPoint + ", " + region;

	        //ArrayList<Business> waypointList = DO.getBusiness(city, state, category[0]);
	        ArrayList<Business> waypointList = findBusiness(category, city, state, company);
	        
	        ArrayList<String> time = new ArrayList<String>();
	        ArrayList<String> distance = new ArrayList<String>();
	        
	        GoogleAPI googleAPI = new GoogleAPI();
	        ArrayList<Business> waypointListSorted = googleAPI.getDirections(start, waypointList, time, distance);

			request.setAttribute("start", start);
			request.setAttribute("waypoints", waypointList);
			request.setAttribute("waypointsSorted", waypointListSorted);
			request.setAttribute("time", time);
			request.setAttribute("distance", distance);
			request.setAttribute("tripResult", (boolean)true);
		}

		RequestDispatcher view = request.getRequestDispatcher("maps.jsp");
	    view.forward(request, response);
	}
	
	public ArrayList<Business> findBusiness(String[] category, String city, String state, String company)
	{
		List<String> categoryList = new ArrayList<String>();
		if(category != null)
		{
			categoryList = Arrays.asList(category);
		}
		String[] restricted = {"Night Life", "Food", "Restaurant", "Spas"};
		List<String> restrictedList = Arrays.asList(restricted); 
		
		List<String> finalList = new ArrayList<String>();
		
		for(int i = 0; i < restricted.length; i++)
		{
			if(!categoryList.contains(restrictedList.get(i)))
			{
				finalList.add(restrictedList.get(i));
			}
		}

		DatabaseOperations DO = new DatabaseOperations();

		ArrayList<Business> business = DO.getBusiness(city, state, company);
		//ArrayList<Business> food = DO.getSelectBusiness(city, state, "Food");
		ArrayList<Business> spas = DO.getSelectBusiness(city, state, company, "Spas");
		ArrayList<Business> nightLife = DO.getSelectBusiness(city, state, company, "Night Life");
		ArrayList<Business> restaurant = DO.getSelectBusiness(city, state, company, "Restaurant");

		ArrayList<Business> finalBusiness = new ArrayList<Business>();

		finalBusiness.add(business.get(0));
		finalBusiness.add(business.get(1));
		finalBusiness.add(restaurant.get(0));
		finalBusiness.add(business.get(2));
		finalBusiness.add(business.get(3));
		
		if(categoryList.contains("Night Life"))
		{
			if(categoryList.contains("Spas"))
			{
				finalBusiness.add(spas.get(0));
			}
			else
			{
				finalBusiness.add(business.get(4));
			}
			finalBusiness.add(restaurant.get(1));
			finalBusiness.add(nightLife.get(0));
		}
		else
		{
			if(categoryList.contains("Spas"))
			{
				finalBusiness.add(spas.get(0));
			}
			else
			{
				finalBusiness.add(business.get(4));
			}
			finalBusiness.add(business.get(5));
			finalBusiness.add(restaurant.get(1));
		}

		return finalBusiness;
	}
}
package DataTypes;

public class Review
{
	private int ID;
	private int BusinessID;
	private Double Rating;
	private String Review;
	
	public Review(int ID, int BusinessID, Double Rating, String Review)
	{
		setID(ID);
		setBusinessID(BusinessID);
		setRating(Rating);
		setReview(Review);
	}

	public int getID()
	{
		return ID;
	}

	public void setID(int iD)
	{
		ID = iD;
	}

	public int getBusinessID()
	{
		return BusinessID;
	}

	public void setBusinessID(int businessID)
	{
		BusinessID = businessID;
	}

	public Double getRating()
	{
		return Rating;
	}

	public void setRating(Double rating)
	{
		Rating = rating;
	}

	public String getReview()
	{
		return Review;
	}

	public void setReview(String review)
	{
		Review = review;
	}
	
}

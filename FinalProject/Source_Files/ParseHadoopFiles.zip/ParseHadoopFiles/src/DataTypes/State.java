package DataTypes;

public class State
{
	private int ID;
	private String State;
	private Country Country;
	
	public State(int ID, Country Country, String State)
	{
		setID(ID);
		setState(State);
		setCountry(Country);
	}

	public int getID()
	{
		return ID;
	}

	public void setID(int iD)
	{
		ID = iD;
	}

	public String getState()
	{
		return State;
	}

	public void setState(String state)
	{
		State = state;
	}

	public Country getCountry()
	{
		return Country;
	}

	public void setCountry(Country country)
	{
		Country = country;
	}
}
package pdp.servlet;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import pdp.DataStructures.Business;

public class GoogleAPI
{
	public static String apiKey = "AIzaSyCR5fhGfy034tcRVRCE9aKLSVbB-mLJkzU";
	public static String keyString = "&key=" + apiKey;
	//public static String keyString = "";
	
	public ArrayList<Business> getDirections(String start, ArrayList<Business> waypointList, ArrayList<String> timeList, ArrayList<String> distanceList)
	{
		 StringBuilder waypoints = new StringBuilder("");
	        
        for (Business business : waypointList)
        {
			waypoints.append(business.getAddress()).append("|");
		}
        waypoints.setCharAt(waypoints.length() - 1, ' ');
        String stringWaypoints = waypoints.toString();
        
		String urlString = "https://maps.googleapis.com/maps/api/directions/json?sensor=false&origin="
				+ start + "&destination=" + start + "&waypoints=optimize:false|" + stringWaypoints + keyString;
        
		urlString = urlString.replace(" ", "");
		
		String result = "";
		try
		{
			URL urlGoogleDirService = new URL(urlString);
	
			URLConnection conn = urlGoogleDirService.openConnection();
	        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	        
	        String readLine = "";
	        
	        while ((readLine = in.readLine()) != null)
	        {
	        	result = result + readLine;
	        }
	        	
	        in.close();
		
			ArrayList<Business> returnList = new ArrayList<Business>();			
			
			JSONParser parser = new JSONParser();
			JSONObject response = null;
		
			response = (JSONObject) parser.parse(result);		
			
			JSONArray routes = (JSONArray) response.get("routes");
			JSONObject getRoutes = (JSONObject) routes.get(0);
			JSONArray order = (JSONArray) getRoutes.get("waypoint_order");
			JSONArray legs = (JSONArray) getRoutes.get("legs");

			for(int i = 0; i < order.size(); i++)
			{
				returnList.add(waypointList.get(Integer.parseInt(order.get(i).toString())));
			}
			
			for(int i = 0; i < legs.size(); i++)
			{
				JSONObject indiLegs = (JSONObject) legs.get(i);
				
				JSONObject duration = (JSONObject) parser.parse(indiLegs.get("duration").toString());
				JSONObject distance = (JSONObject) parser.parse(indiLegs.get("distance").toString());

				timeList.add(duration.get("text").toString());
				distanceList.add(distance.get("text").toString());
			}
			
			return returnList;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
}

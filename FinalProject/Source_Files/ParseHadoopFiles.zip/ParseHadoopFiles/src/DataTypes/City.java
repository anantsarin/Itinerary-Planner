package DataTypes;

public class City
{
	private int ID;
	private State State;
	private String City;
	
	public City(int ID, State State, String City)
	{
		setID(ID);
		setCity(City);
		setState(State);
	}

	public int getID()
	{
		return ID;
	}

	public void setID(int iD)
	{
		ID = iD;
	}

	public State getState()
	{
		return State;
	}

	public void setState(State state)
	{
		State = state;
	}
	
	public String getCity()
	{
		return City;
	}

	public void setCity(String city)
	{
		City = city;
	}

}
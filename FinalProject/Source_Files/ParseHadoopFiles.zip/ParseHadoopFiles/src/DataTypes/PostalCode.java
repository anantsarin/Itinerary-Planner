package DataTypes;

public class PostalCode
{
	private int ID;
	private City City;
	private String PostalCode;
	
	public PostalCode(int ID, City City, String PostalCode)
	{
		setID(ID);
		setCity(City);
		setPostalCode(PostalCode);
	}

	public int getID()
	{
		return ID;
	}

	public void setID(int iD)
	{
		ID = iD;
	}
	
	public City getCity()
	{
		return City;
	}

	public void setCity(City city)
	{
		City = city;
	}
	
	public String getPostalCode()
	{
		return PostalCode;
	}

	public void setPostalCode(String postalCode)
	{
		PostalCode = postalCode;
	}

}
package hadoopFiles;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import databaseConnection.DatabaseOperations;

public class Parse
{
	public static void main(String[] args)
	{
		parseOutput();
	}
	
	public static void parseOutput()
	{
		DatabaseOperations DO = new DatabaseOperations();
		
		File folder = new File("processedFiles/");
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles)
		{
			if (file.isFile())
			{
				try
				{
					BufferedReader br;
					br = new BufferedReader(new FileReader(file));
					
					String line;
					while ((line = br.readLine()) != null)
					{			    								
		    			int business = Integer.parseInt(line.split(" ")[0].trim().replace(".txt", ""));
		    			
		    			System.out.println("Processing Business " + business);
		    			
		    			String[] parts = line.replace(line.split(" ")[0], "").split(",");
		    			
		    			int familyWordCount = (int) Float.parseFloat(parts[0].split("=")[1]);
		    			int familyNegative = (int) Float.parseFloat(parts[1].split("=")[1]);
		    			int familyPositive = (int) Float.parseFloat(parts[2].split("=")[1]);
		    			int coupleWordCount = (int) Float.parseFloat(parts[3].split("=")[1]);
		    			int couplePositive = (int) Float.parseFloat(parts[4].split("=")[1]);
		    			int coupleNegative = (int) Float.parseFloat(parts[5].split("=")[1]);
		    			int friendsWordCount = (int) Float.parseFloat(parts[6].split("=")[1]);
		    			int friendsPositive = (int) Float.parseFloat(parts[7].split("=")[1]);
		    			int friendsNegative = (int) Float.parseFloat(parts[8].split("=")[1]);
		    			float score = Float.parseFloat(parts[9].split("=")[1]);
		    			float finalPercentage = (score/DO.reviewsCount(business))*100;
		    			float finalRating = 0;
		    			
		    			if(finalPercentage > 95)
		    			{
		    				finalRating = 5;
		    			}
		    			else if(finalPercentage > 85)
		    			{
		    				finalRating = (float) 4.5;
		    			}
		    			else if(finalPercentage > 65)
		    			{
		    				finalRating = (float) 4.0;
		    			}
		    			else if(finalPercentage > 55)
		    			{
		    				finalRating = (float) 3.5;
		    			}
		    			else if(finalPercentage > 45)
		    			{
		    				finalRating = (float) 3.0;
		    			}
		    			else if(finalPercentage > 35)
		    			{
		    				finalRating = (float) 2.5;
		    			}
		    			else if(finalPercentage > 25)
		    			{
		    				finalRating = (float) 2.0;
		    			}
		    			else if(finalPercentage > 20)
		    			{
		    				finalRating = (float) 1.5;
		    			}
		    			else if(finalPercentage > 15)
		    			{
		    				finalRating = (float) 1.0;
		    			}
		    			else if(finalPercentage < 15)
		    			{
		    				finalRating = (float) 0.5;
		    			}
		    			
		    			DO.insertPreProcessedData(business, finalRating, score, 
		    											familyWordCount, familyPositive, familyNegative, 
		    											coupleWordCount, couplePositive, coupleNegative, 
		    											friendsWordCount, friendsPositive, friendsNegative);
			    	 }
			    	 br.close();
		    	 }
		    	 catch (FileNotFoundException e)
		    	 {
					e.printStackTrace();
		    	 }
		    	 catch (IOException e)
		    	 {
					e.printStackTrace();
		    	 }
		     }
		 }
	}
}
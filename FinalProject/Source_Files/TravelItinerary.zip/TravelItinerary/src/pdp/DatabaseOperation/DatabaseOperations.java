package pdp.DatabaseOperation;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import pdp.DataStructures.Business;

public class DatabaseOperations
{
	private Connection connect = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;
	
	private static String databaseName = "travel_itinerary";
	private static String url = "jdbc:mysql://localhost:3306/" + databaseName;
    private static String driver = "com.mysql.jdbc.Driver";
    private static String userName = "root";
    private static String password = "root";
    
    public DatabaseOperations()
	{
        try
        {
        	Class.forName(driver);
            connect = DriverManager.getConnection(url, DatabaseOperations.userName, DatabaseOperations.password);
		}
        catch (SQLException | ClassNotFoundException e)
        {
			e.printStackTrace();
		}
	}
    
	public DatabaseOperations(String userName, String password, String URL)
	{
        try
        {
        	setUserName(userName);
        	setPassword(password);
        	setURL(URL);
        	Class.forName(driver);
            connect = DriverManager.getConnection(url, DatabaseOperations.userName, DatabaseOperations.password);
		}
        catch (SQLException | ClassNotFoundException e)
        {
			e.printStackTrace();
		}
	}
	
	public void setUserName(String userName)
	{
		DatabaseOperations.userName = userName;
	}
	
	public void setPassword(String password)
	{
		DatabaseOperations.password = password;
	}
	
	public void setURL(String URL)
	{
		DatabaseOperations.url = URL + "/" + databaseName;
	}
	
	public void closeConnection()
	{
		try
		{
			if(connect!=null)
			{
				connect.close();
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public ArrayList<String> getStates()
	{
		try
		{
			ArrayList<String> states = new ArrayList<String>();
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM states WHERE ID IN (SELECT DISTINCT State FROM cities WHERE ID IN (SELECT DISTINCT YelpCity FROM business_yelpcity));");

			resultSet = preparedStatement.executeQuery();

			while(resultSet.next())
			{
				states.add(resultSet.getString(3));
			}
			return states;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList<String> getCities(String state)
	{
		try
		{
			ArrayList<String> states = new ArrayList<String>();
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM cities WHERE State = (SELECT ID FROM states where State = ?) AND ID IN (SELECT DISTINCT YelpCity FROM business_yelpcity);");
			
			preparedStatement.setString(1, state.trim());
			
			resultSet = preparedStatement.executeQuery();

			while(resultSet.next())
			{
				states.add(resultSet.getString(3));
			}
			return states;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList<Business> getSelectBusiness(String City, String State, String Company, String Category)
	{
		try
		{
			ArrayList<Business> business = new ArrayList<Business>();
			preparedStatement = connect
			        .prepareStatement( "SELECT *, "
			        				 + "(CASE "
			        				 + "WHEN Historic = 1 AND Company LIKE '%" + Company + "%' "
			        				 + "THEN TotalRating + 4 "
			        				 + "WHEN Historic = 1 "
			        				 + "THEN TotalRating + 3 "
			        				 + "WHEN Company LIKE '%" + Company + "%' "
			        				 + "THEN TotalRating + 1 "
			        				 + "ELSE "
			        				 + "TotalRating "
									 + "END) AS 'FinalRating' "
									 + "FROM "
			        				 + "	(SELECT "
									 + "    	B.ID, Name, URL, B.Rating, "
									 + "		CASE " 
									 + "		WHEN ReviewCount >= 1000 THEN 5 + ppd.Rating "
									 + "		WHEN ReviewCount >= 800 THEN 4.5 + ppd.Rating "
									 + "		WHEN ReviewCount >= 700 THEN 4 + ppd.Rating "
									 + "		WHEN ReviewCount >= 600 THEN 3.5 + ppd.Rating "
									 + "		WHEN ReviewCount >= 500 THEN 3 + ppd.Rating "
									 + "		WHEN ReviewCount >= 350 THEN 2.5 + ppd.Rating "
									 + "		WHEN ReviewCount >= 200 THEN 2 + ppd.Rating "
									 + "		WHEN ReviewCount >= 100 THEN 1.5 + ppd.Rating "
									 + "		WHEN ReviewCount >= 50 THEN 1 + ppd.Rating "
									 + "		WHEN ReviewCount >0 THEN 0.5 + ppd.Rating "
									 + "		WHEN ReviewCount = 0 THEN 0 + ppd.Rating "
									 + "		END AS 'TotalRating', "
									 + "		CASE "
									 + "			WHEN "
									 + "				(SELECT " 
									 + "					GROUP_CONCAT((SELECT GROUP_CONCAT(Category) FROM categories WHERE ID = BC.CategoryID)) AS 'Categories' " 
									 + "				FROM " 
									 + "					business_categories AS BC WHERE BC.BusinessID = b.ID) LIKE '%Landmark%' "
									 + "				THEN 1 "
									 + "			WHEN "
									 + "				(SELECT " 
									 + "					GROUP_CONCAT((SELECT GROUP_CONCAT(Category) FROM categories WHERE ID = BC.CategoryID)) AS 'Categories' " 
									 + "				FROM " 
									 + "					business_categories AS BC WHERE BC.BusinessID = b.ID) LIKE '%Historical Building%' "
									 + "				THEN 1 "
									 + "				ELSE 0 "
									 + "			END "
									 + "			AS 'Historic', "
								     + "		ReviewCount, Phone, "
								     + "		(SELECT (SELECT Category FROM yelp_categories WHERE ID = BYC.YelpCategoryID LIMIT 1) as Category FROM business_yelpcategories as BYC WHERE BYC.BusinessID = b.ID LIMIT 1) as 'Category', "
								     + "		(SELECT (SELECT TimeHours FROM yelp_categories WHERE ID = BYC.YelpCategoryID LIMIT 1) as Category FROM business_yelpcategories as BYC WHERE BYC.BusinessID = b.ID LIMIT 1) as 'CategoryTime', "
									 + "    	CONCAT((CASE WHEN Address_Line1 IS NULL THEN '' ELSE Address_Line1 END) , " 
									 + "		(CASE WHEN Address_Line2 IS NULL THEN '' ELSE CONCAT(',',Address_Line2) END), ',', " 
									 + " 		(SELECT City from cities WHERE ID = B.City), ',', " 
									 + "		(SELECT State from states WHERE ID = B.State), ',', " 
									 + "		(SELECT Country from countries WHERE ID = B.Country) "
									 + "		) AS Address, "
									 + "		ImageURL, RatingImgURL, RatingImgURLSmall, RatingImgURLLarge, Snippet, SnippetImageURL, "
									 + "		ppd.Rating as PPDRating, "
									 + "		(SELECT CONCAT(CASE WHEN FamilyWordCount > 10 AND (FamilyPositive > FamilyNegative) THEN 'Family,' ELSE '' END, "
									 + "		CASE WHEN CoupleWordCount > 10 AND (CouplePositive > CoupleNegative) THEN 'Couple,' ELSE '' END, "
									 + "		CASE WHEN FriendsWordCount > 10 AND (FriendsPositive > FriendsNegative) THEN 'Friends' ELSE '' END) as 'Company' "
									 + "		FROM preprocessed_data WHERE BusinessID = B.ID) as 'Company' "
									 + " 	FROM "
									 + " 		business as B "
									 + "			INNER JOIN preprocessed_data as ppd "
									 + "			ON ppd.BusinessID = B.ID "
									 + "	WHERE B.ID IN "
									 + "		(SELECT BusinessID FROM business_yelpcategories WHERE BusinessID IN "
									 + "			(SELECT "
									 + "				BusinessID "
									 + " 			FROM "
									 + "				business_yelpcity " 
									 + "			WHERE " 
									 + "				YelpCity = (SELECT ID FROM cities " 
									 + "							WHERE " 
									 + "								State = (SELECT ID FROM states WHERE State = ?) " 
									 + "							AND "
									 + "								City = ?)))"
									 + "	ORDER BY "
									 + "	TotalRating DESC) as temp "
									 + "WHERE Category = ?;");

			preparedStatement.setString(1,State);
			preparedStatement.setString(2, City);
			preparedStatement.setString(3, Category);
			
			resultSet = preparedStatement.executeQuery();

			while(resultSet.next())
			{
				Business tempBusiness = new Business();
				tempBusiness.setID(resultSet.getInt(1));
				tempBusiness.setName(resultSet.getString(2));
				tempBusiness.setURL(resultSet.getString(3));
				tempBusiness.setRating(resultSet.getFloat(4));
				tempBusiness.setTotalRating(resultSet.getFloat(5));
				tempBusiness.setHistoric(resultSet.getBoolean(6));
				tempBusiness.setReviewCount(resultSet.getInt(7));
				tempBusiness.setPhone(resultSet.getString(8));
				tempBusiness.setCategory(resultSet.getString(9));
				tempBusiness.setTime(resultSet.getFloat(10));
				tempBusiness.setAddress(resultSet.getString(11));
				tempBusiness.setImageURL(resultSet.getString(12));
				tempBusiness.setRatingImgURL(resultSet.getString(13));
				tempBusiness.setRatingImgURLSmall(resultSet.getString(14));
				tempBusiness.setRatingImgURLLarge(resultSet.getString(15));
				tempBusiness.setSnippet(resultSet.getString(16));
				tempBusiness.setSnippetImageURL(resultSet.getString(17));
				tempBusiness.setPpdRating(resultSet.getFloat(18));
				tempBusiness.setFinalRating(resultSet.getFloat(20));
				business.add(tempBusiness);
			}
			return business;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList<Business> getBusiness(String City, String State, String Company)
	{
		try
		{
			ArrayList<Business> business = new ArrayList<Business>();
			preparedStatement = connect
					  .prepareStatement( "SELECT *, "
	        				 + "(CASE "
	        				 + "WHEN Historic = 1 AND Company LIKE '%" + Company + "%' "
	        				 + "THEN TotalRating + 4 "
	        				 + "WHEN Historic = 1 "
	        				 + "THEN TotalRating + 3 "
	        				 + "WHEN Company LIKE '%" + Company + "%' "
	        				 + "THEN TotalRating + 1 "
	        				 + "ELSE "
	        				 + "TotalRating "
							 + "END) AS 'FinalRating' "
							 + "FROM "
	        				 + "	(SELECT "
							 + "    	B.ID, Name, URL, B.Rating, "
							 + "		CASE " 
							 + "		WHEN ReviewCount >= 1000 THEN 5 + ppd.Rating "
							 + "		WHEN ReviewCount >= 800 THEN 4.5 + ppd.Rating "
							 + "		WHEN ReviewCount >= 700 THEN 4 + ppd.Rating "
							 + "		WHEN ReviewCount >= 600 THEN 3.5 + ppd.Rating "
							 + "		WHEN ReviewCount >= 500 THEN 3 + ppd.Rating "
							 + "		WHEN ReviewCount >= 350 THEN 2.5 + ppd.Rating "
							 + "		WHEN ReviewCount >= 200 THEN 2 + ppd.Rating "
							 + "		WHEN ReviewCount >= 100 THEN 1.5 + ppd.Rating "
							 + "		WHEN ReviewCount >= 50 THEN 1 + ppd.Rating "
							 + "		WHEN ReviewCount >0 THEN 0.5 + ppd.Rating "
							 + "		WHEN ReviewCount = 0 THEN 0 + ppd.Rating "
							 + "		END AS 'TotalRating', "
							 + "		CASE "
							 + "			WHEN "
							 + "				(SELECT " 
							 + "					GROUP_CONCAT((SELECT GROUP_CONCAT(Category) FROM categories WHERE ID = BC.CategoryID)) AS 'Categories' " 
							 + "				FROM " 
							 + "					business_categories AS BC WHERE BC.BusinessID = b.ID) LIKE '%Landmark%' "
							 + "				THEN 1 "
							 + "			WHEN "
							 + "				(SELECT " 
							 + "					GROUP_CONCAT((SELECT GROUP_CONCAT(Category) FROM categories WHERE ID = BC.CategoryID)) AS 'Categories' " 
							 + "				FROM " 
							 + "					business_categories AS BC WHERE BC.BusinessID = b.ID) LIKE '%Historical Building%' "
							 + "				THEN 1 "
							 + "				ELSE 0 "
							 + "			END "
							 + "			AS 'Historic', "
						     + "		ReviewCount, Phone, "
						     + "		(SELECT (SELECT Category FROM yelp_categories WHERE ID = BYC.YelpCategoryID LIMIT 1) as Category FROM business_yelpcategories as BYC WHERE BYC.BusinessID = b.ID LIMIT 1) as 'Category', "
						     + "		(SELECT (SELECT TimeHours FROM yelp_categories WHERE ID = BYC.YelpCategoryID LIMIT 1) as Category FROM business_yelpcategories as BYC WHERE BYC.BusinessID = b.ID LIMIT 1) as 'CategoryTime', "
							 + "    	CONCAT((CASE WHEN Address_Line1 IS NULL THEN '' ELSE Address_Line1 END) , " 
							 + "		(CASE WHEN Address_Line2 IS NULL THEN '' ELSE CONCAT(',',Address_Line2) END), ',', " 
							 + " 		(SELECT City from cities WHERE ID = B.City), ',', " 
							 + "		(SELECT State from states WHERE ID = B.State), ',', " 
							 + "		(SELECT Country from countries WHERE ID = B.Country) "
							 + "		) AS Address, "
							 + "		ImageURL, RatingImgURL, RatingImgURLSmall, RatingImgURLLarge, Snippet, SnippetImageURL, "
							 + "		ppd.Rating as PPDRating, "
							 + "		(SELECT CONCAT(CASE WHEN FamilyWordCount > 10 AND (FamilyPositive > FamilyNegative) THEN 'Family,' ELSE '' END, "
							 + "		CASE WHEN CoupleWordCount > 10 AND (CouplePositive > CoupleNegative) THEN 'Couple,' ELSE '' END, "
							 + "		CASE WHEN FriendsWordCount > 10 AND (FriendsPositive > FriendsNegative) THEN 'Friends' ELSE '' END) as 'Company' "
							 + "		FROM preprocessed_data WHERE BusinessID = B.ID) as 'Company' "
							 + "	FROM "
							 + " 		business as B "
							 + "			INNER JOIN preprocessed_data as ppd "
							 + "			ON ppd.BusinessID = B.ID "
							 + "	WHERE B.ID IN "
							 + "		(SELECT BusinessID FROM business_yelpcategories WHERE BusinessID IN "
							 + "			(SELECT "
							 + "				BusinessID "
							 + " 			FROM "
							 + "				business_yelpcity " 
							 + "			WHERE " 
							 + "				YelpCity = (SELECT ID FROM cities " 
							 + "							WHERE " 
							 + "								State = (SELECT ID FROM states WHERE State = ?) " 
							 + "							AND "
							 + "								City = ?)))"
							 + "	ORDER BY "
							 + "	TotalRating DESC) as temp "
									 + "WHERE Category != 'Night Life' AND Category != 'Food' AND Category != 'Restaurant' AND Category != 'Spas' ORDER BY FinalRating DESC;");
									 //+ "WHERE Category NOT IN (?);");

			preparedStatement.setString(1,State);
			preparedStatement.setString(2, City);
			
			resultSet = preparedStatement.executeQuery();

			while(resultSet.next())
			{
				Business tempBusiness = new Business();
				tempBusiness.setID(resultSet.getInt(1));
				tempBusiness.setName(resultSet.getString(2));
				tempBusiness.setURL(resultSet.getString(3));
				tempBusiness.setRating(resultSet.getFloat(4));
				tempBusiness.setTotalRating(resultSet.getFloat(5));
				tempBusiness.setHistoric(resultSet.getBoolean(6));
				tempBusiness.setReviewCount(resultSet.getInt(7));
				tempBusiness.setPhone(resultSet.getString(8));
				tempBusiness.setCategory(resultSet.getString(9));
				tempBusiness.setTime(resultSet.getFloat(10));
				tempBusiness.setAddress(resultSet.getString(11));
				tempBusiness.setImageURL(resultSet.getString(12));
				tempBusiness.setRatingImgURL(resultSet.getString(13));
				tempBusiness.setRatingImgURLSmall(resultSet.getString(14));
				tempBusiness.setRatingImgURLLarge(resultSet.getString(15));
				tempBusiness.setSnippet(resultSet.getString(16));
				tempBusiness.setSnippetImageURL(resultSet.getString(17));
				tempBusiness.setPpdRating(resultSet.getFloat(18));
				tempBusiness.setFinalRating(resultSet.getFloat(20));
				business.add(tempBusiness);
			}
			return business;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
}
package pdp.DataStructures;

public class Business
{
	private int ID;
	private String Name;
	private String  URL;
	private float Rating;
	private float TotalRating;
	private boolean Historic;
	private int ReviewCount;
	private String Phone;
	private String Category;
	private Float Time;
	private String Address;
	private String ImageURL;
	private String RatingImgURL;
	private String RatingImgURLSmall;
	private String RatingImgURLLarge;
	private String Snippet;
	private String SnippetImageURL;
	private float ppdRating;
	private float FinalRating;
	
	public int getID()
	{
		return ID;
	}
	
	public void setID(int iD)
	{
		ID = iD;
	}
	
	public String getName()
	{
		return Name;
	}
	
	public void setName(String name)
	{
		Name = name;
	}
	
	public float getRating()
	{
		return Rating;
	}
	
	public void setRating(float rating)
	{
		Rating = rating;
	}
	
	public int getReviewCount()
	{
		return ReviewCount;
	}
	
	public void setReviewCount(int reviewCount)
	{
		ReviewCount = reviewCount;
	}
	
	public String getURL()
	{
		return URL;
	}
	
	public void setURL(String uRL)
	{
		URL = uRL;
	}
	
	public String getPhone()
	{
		return Phone;
	}
	
	public void setPhone(String phone)
	{
		Phone = phone;
	}
	
	public String getAddress()
	{
		return Address;
	}
	
	public void setAddress(String address)
	{
		Address = address;
	}

	public String getImageURL()
	{
		return ImageURL;
	}

	public void setImageURL(String imageURL)
	{
		ImageURL = imageURL;
	}

	public String getRatingImgURL()
	{
		return RatingImgURL;
	}

	public void setRatingImgURL(String ratingImgURL)
	{
		RatingImgURL = ratingImgURL;
	}

	public String getRatingImgURLSmall()
	{
		return RatingImgURLSmall;
	}

	public void setRatingImgURLSmall(String ratingImgURLSmall)
	{
		RatingImgURLSmall = ratingImgURLSmall;
	}

	public String getRatingImgURLLarge()
	{
		return RatingImgURLLarge;
	}

	public void setRatingImgURLLarge(String ratingImgURLLarge)
	{
		RatingImgURLLarge = ratingImgURLLarge;
	}

	public String getSnippet()
	{
		return Snippet;
	}

	public void setSnippet(String snippet)
	{
		Snippet = snippet;
	}

	public String getSnippetImageURL()
	{
		return SnippetImageURL;
	}

	public void setSnippetImageURL(String snippetImageURL)
	{
		SnippetImageURL = snippetImageURL;
	}

	public float getTotalRating()
	{
		return TotalRating;
	}

	public void setTotalRating(float totalRating)
	{
		TotalRating = totalRating;
	}

	public String getCategory()
	{
		return Category;
	}

	public void setCategory(String category)
	{
		Category = category;
	}

	public boolean isHistoric()
	{
		return Historic;
	}

	public void setHistoric(boolean historic)
	{
		Historic = historic;
	}

	public float getFinalRating()
	{
		return FinalRating;
	}

	public void setFinalRating(float finalRating)
	{
		FinalRating = finalRating;
	}

	public Float getTime()
	{
		return Time;
	}

	public void setTime(Float time)
	{
		Time = time;
	}

	public float getPpdRating()
	{
		return ppdRating;
	}

	public void setPpdRating(float ppdRating)
	{
		this.ppdRating = ppdRating;
	}
}
package databaseConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DataTypes.*;

public class DatabaseOperations
{
	private Connection connect = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;
	
	private static String databaseName = "travel_itinerary";
	private static String url = "jdbc:mysql://localhost:3306/" + databaseName;
    private static String driver = "com.mysql.jdbc.Driver";
    private static String userName = "root";
    private static String password = "root";
    
    public DatabaseOperations()
	{
        try
        {
        	Class.forName(driver);
            connect = DriverManager.getConnection(url, DatabaseOperations.userName, DatabaseOperations.password);
		}
        catch (SQLException | ClassNotFoundException e)
        {
			e.printStackTrace();
		}
	}
    
	public DatabaseOperations(String userName, String password, String URL)
	{
        try
        {
        	setUserName(userName);
        	setPassword(password);
        	setURL(URL);
        	Class.forName(driver);
            connect = DriverManager.getConnection(url, DatabaseOperations.userName, DatabaseOperations.password);
		}
        catch (SQLException | ClassNotFoundException e)
        {
			e.printStackTrace();
		}
	}
	
	public void setUserName(String userName)
	{
		DatabaseOperations.userName = userName;
	}
	
	public void setPassword(String password)
	{
		DatabaseOperations.password = password;
	}
	
	public void setURL(String URL)
	{
		DatabaseOperations.url = URL + "/" + databaseName;
	}
	
	public void closeConnection()
	{
		try
		{
			if(connect!=null)
			{
				connect.close();
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public Business insertBusiness(Business business, City yelpCity)
	{
		try
	    {   
			Business BusinessLookUp = getBusiness(business.getBusinessID());
			if(BusinessLookUp == null)
			{
				preparedStatement = connect
		            .prepareStatement("insert into business values (default, ?, ?, ?, ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
	
		        preparedStatement.setString(1, business.getBusinessID());
		        preparedStatement.setString(2, business.getName());
		        preparedStatement.setString(3, business.getURL());
		        preparedStatement.setDouble(4, business.getRating());
		        preparedStatement.setInt(5, business.getReviewsCount());
		        preparedStatement.setString(6, business.getPhone());
		        
		        if ( business.getAddressLine1() == null)
		        {
		        	preparedStatement.setNull(7, java.sql.Types.INTEGER);
		        }
		        else
		        {
		        	preparedStatement.setString(7, business.getAddressLine1());
		        }	
		        
		        if ( business.getAddressLine2() == null)
		        {
		        	preparedStatement.setNull(8, java.sql.Types.INTEGER);
		        }
		        else
		        {
		        	preparedStatement.setString(8, business.getAddressLine2());
		        }		        
		        
		        if ( business.getCity() == null)
		        {
		        	preparedStatement.setNull(9, java.sql.Types.INTEGER);
		        }
		        else
		        {
		        	preparedStatement.setInt(9, business.getCity().getID());
		        }
		        
		        if ( business.getState() == null)
		        {
		        	preparedStatement.setNull(10, java.sql.Types.INTEGER);
		        }
		        else
		        {
		        	preparedStatement.setInt(10, business.getState().getID());
		        }
		        
		        if ( business.getCountry() == null)
		        {
		        	preparedStatement.setNull(11, java.sql.Types.INTEGER);
		        }
		        else
		        {
		        	preparedStatement.setInt(11, business.getCountry().getID());
		        }
		        
		        if ( business.getPostal_Code() == null)
		        {
		        	preparedStatement.setNull(12, java.sql.Types.INTEGER);
		        }
		        else
		        {
		        	preparedStatement.setInt(12, business.getPostal_Code().getID());
		        }
		        
		        if ( business.getImageURL() == null)
		        {
		        	preparedStatement.setNull(13, java.sql.Types.NULL);
		        }
		        else
		        {
		        	preparedStatement.setString(13, business.getImageURL());
		        }
		        
		        if ( business.getRatingImgURL() == null)
		        {
		        	preparedStatement.setNull(14, java.sql.Types.NULL);
		        }
		        else
		        {
		        	preparedStatement.setString(14, business.getRatingImgURL());
		        }
		        
		        if ( business.getRatingImgURLSmall() == null)
		        {
		        	preparedStatement.setNull(15, java.sql.Types.NULL);
		        }
		        else
		        {
		        	preparedStatement.setString(15, business.getRatingImgURLSmall());
		        }
		        
		        if ( business.getRatingImgURLLarge() == null)
		        {
		        	preparedStatement.setNull(16, java.sql.Types.NULL);
		        }
		        else
		        {
		        	preparedStatement.setString(16, business.getRatingImgURLLarge());
		        }
		        
		        if ( business.getSnippet() == null)
		        {
		        	preparedStatement.setNull(17, java.sql.Types.NULL);
		        }
		        else
		        {
		        	preparedStatement.setString(17, business.getSnippet());
		        }
		        
		        if ( business.getSnippetImageURL() == null)
		        {
		        	preparedStatement.setNull(18, java.sql.Types.NULL);
		        }
		        else
		        {
		        	preparedStatement.setString(18, business.getSnippetImageURL());
		        }
		        
		        preparedStatement.executeUpdate();
		        		        
		        BusinessLookUp = getBusiness(business.getBusinessID());
		        insertYelpCity(yelpCity, BusinessLookUp);
		        return BusinessLookUp;
			}
			else
			{
				insertYelpCity(yelpCity, BusinessLookUp);
				
				BusinessLookUp = getBusiness(business.getBusinessID());
				
				if(BusinessLookUp.getImageURL() != business.getImageURL())
				{
					preparedStatement = connect
								.prepareStatement("update business SET ImageURL = ?, RatingImgURL = ?,"
										+ "RatingImgURLSmall = ?, RatingImgURLLarge = ?, Snippet = ?,"
										+ "SnippetImageURL = ? WHERE BusinessID = ?");
					preparedStatement.setString(1, business.getImageURL());
					preparedStatement.setString(2, business.getRatingImgURL());
					preparedStatement.setString(3, business.getRatingImgURLSmall());
					preparedStatement.setString(4, business.getRatingImgURLLarge());
					preparedStatement.setString(5, business.getSnippet());
					preparedStatement.setString(6, business.getSnippetImageURL());
					preparedStatement.setString(7, BusinessLookUp.getBusinessID());
					
					preparedStatement.executeUpdate();
				}
		        
				if(BusinessLookUp.getReviewsCount() != business.getReviewsCount())
				{
					preparedStatement = connect
				            .prepareStatement("update business SET ReviewCount = ? WHERE BusinessID = ?");
			
				    preparedStatement.setInt(1, business.getReviewsCount());
				    preparedStatement.setString(2, BusinessLookUp.getBusinessID());
				    
				    preparedStatement.executeUpdate();
				}
				
				BusinessLookUp = getBusiness(business.getBusinessID());
				
		        return BusinessLookUp;
			}
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
		return null;
	}
	
	public Business getBusiness(String Business)
	{
		try
		{
			ResultSet rs = null;
			preparedStatement = connect
			        .prepareStatement("SELECT ID, BusinessID, Name, URL, Rating, ReviewCount, Phone, Address_Line1, Address_Line2," + 
			        			"(SELECT City FROM cities WHERE ID = B.City) as 'City', (SELECT State FROM states WHERE ID = B.State) AS 'State'," + 
			        			"(SELECT Country FROM countries WHERE ID = B.Country) AS 'Country', (SELECT Postal_Code FROM postal_codes WHERE ID = B.PostalCode) AS 'Postal_Code'," +  
			        			"ImageURL, RatingImgURL, RatingImgURLSmall, RatingImgURLLarge, Snippet, SnippetImageURL FROM travel_itinerary.business AS B WHERE BusinessID = ?;");
			preparedStatement.setString(1, Business);
			rs = preparedStatement.executeQuery();
			
			if(rs.next())
			{
				Country country = getCountry(rs.getString(12));
				State state = getState(rs.getString(11), country);
				City city = getCity(rs.getString(10), state);
				PostalCode pc = getPostalCode(rs.getString(13), city);
				
				Business returnBusiness = new Business(rs.getInt(1),rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getDouble(5),
						rs.getInt(6), rs.getString(7), rs.getString(8),
						rs.getString(9), city, state, country, pc, rs.getString(14),
						rs.getString(15), rs.getString(16), rs.getString(17),
						rs.getString(18), rs.getString(19));
				
				return returnBusiness;
			}
			else
			{
				return null;
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean getyelpCity(City yelpCity, Business business)
	{
		try
		{
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM business_yelpcity WHERE BusinessID = ? AND YelpCity = ?;");
			
			preparedStatement.setInt(1, business.getID());
			preparedStatement.setInt(2, yelpCity.getID());
			
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return false;
	}
	
	public void insertYelpCity(City yelpCity, Business business)
	{
		try
	    {   
			boolean yelpCityLookUp = getyelpCity(yelpCity, business);
			if(yelpCityLookUp == false)
			{
		        preparedStatement = connect
		            .prepareStatement("insert into business_yelpcity values (default, ?, ?)");
	
		        preparedStatement.setInt(1, business.getID());
		        preparedStatement.setInt(2, yelpCity.getID());
		        preparedStatement.executeUpdate();
			}
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
	}
	
	public Country insertCountry(String Country)
	{
		try
	    {   
			Country CountryLookUp = getCountry(Country);
			if(CountryLookUp == null)
			{
		        preparedStatement = connect
		            .prepareStatement("insert into countries values (default, ?)");
	
		        preparedStatement.setString(1, Country);
		        preparedStatement.executeUpdate();
		        
		        CountryLookUp = getCountry(Country);
		        return CountryLookUp;
			}
			else
			{
				return CountryLookUp;
			}

	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
		return null;
	}
	
	public Country getCountry(String Country)
	{
		try
		{
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM countries WHERE Country = ?;");
			preparedStatement.setString(1, Country);
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next())
			{
				Country returnCountry = new Country(resultSet.getInt(1),resultSet.getString(2));
				return returnCountry;
			}
			else
			{
				return null;
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public State insertState(String State, Country Country)
	{
		try
	    {   
			State StateLookUp = getState(State, Country);
			if(StateLookUp == null)
			{
		        preparedStatement = connect
		            .prepareStatement("insert into states values (default, ?, ?)");
	
		        preparedStatement.setInt(1, Country.getID());
		        preparedStatement.setString(2, State);
		        preparedStatement.executeUpdate();
		        
		        StateLookUp = getState(State, Country);
		        return StateLookUp;
			}
			else
			{
				return StateLookUp;
			}

	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
		return null;
	}
	
	public State getState(String State, Country Country)
	{
		try
		{
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM states WHERE State = ? AND Country = ?;");
			preparedStatement.setString(1, State);
			preparedStatement.setInt(2, Country.getID());
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next())
			{
				State returnState = new State(resultSet.getInt(1), Country, resultSet.getString(3));
				return returnState;
			}
			else
			{
				return null;
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public City insertCity(String City, State State)
	{
		try
	    {   
			City CityLookUp = getCity(City, State);
			if(CityLookUp == null)
			{
		        preparedStatement = connect
		            .prepareStatement("insert into cities values (default, ?, ?)");
	
		        preparedStatement.setInt(1, State.getID());
		        preparedStatement.setString(2, City);
		        preparedStatement.executeUpdate();
		        
		        CityLookUp = getCity(City, State);
		        return CityLookUp;
			}
			else
			{
				return CityLookUp;
			}

	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
		return null;
	}

	public City insertCity(String City, String State, Country Country)
	{
		try
	    {   
			State StateLookUp = getState(State.trim(), Country);
			City CityLookUp = getCity(City, StateLookUp);
			
			if(CityLookUp == null)
			{
		        preparedStatement = connect
		            .prepareStatement("insert into cities values (default, ?, ?)");
	
		        preparedStatement.setInt(1, StateLookUp.getID());
		        preparedStatement.setString(2, City);
		        preparedStatement.executeUpdate();
		        
		        CityLookUp = getCity(City, StateLookUp);
		        return CityLookUp;
			}
			else
			{
				return CityLookUp;
			}

	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
		return null;
	}
	
	public City getCity(String City, State State)
	{
		try
		{
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM cities WHERE State = ? AND City = ?;");
			
			preparedStatement.setInt(1, State.getID());
			preparedStatement.setString(2, City);
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next())
			{
				City returnCity = new City(resultSet.getInt(1), State, resultSet.getString(3));
				return returnCity;
			}
			else
			{
				return null;
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public PostalCode insertPostalCode(String PostalCode, City City)
	{
		try
	    {   
			PostalCode PostalCodeLookUp = getPostalCode(PostalCode, City);
			if(PostalCodeLookUp == null)
			{
		        preparedStatement = connect
		            .prepareStatement("insert into postal_codes values (default, ?, ?)");
	
		        preparedStatement.setInt(1, City.getID());
		        preparedStatement.setString(2, PostalCode);
		        preparedStatement.executeUpdate();
		        
		        PostalCodeLookUp = getPostalCode(PostalCode, City);
		        return PostalCodeLookUp;
			}
			else
			{
				return PostalCodeLookUp;
			}

	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
		return null;
	}
	
	public PostalCode getPostalCode(String PostalCode, City City)
	{
		try
		{
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM postal_codes WHERE City = ? AND Postal_Code = ?;");

			preparedStatement.setInt(1, City.getID());
			preparedStatement.setString(2, PostalCode);
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next())
			{
				PostalCode returnPostalCode = new PostalCode(resultSet.getInt(1), City,resultSet.getString(3));
				return returnPostalCode;
			}
			else
			{
				return null;
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public void insertReview(Business business, Double Rating, String Review)
	{
		try
	    {		
	        preparedStatement = connect
	            .prepareStatement("insert into reviews values (default, ?, ?, ?)");

	        preparedStatement.setInt(1, business.getID());
	        preparedStatement.setDouble(2, Rating);
	        preparedStatement.setString(3, Review);
	        preparedStatement.executeUpdate();

	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
	}
	
	public ArrayList<Review> getReviews(String BusinessID)
	{
		try
		{
			ArrayList<Review> Reviews = new ArrayList<Review>();
			
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM reviews WHERE BusinessID = ?;");
			preparedStatement.setString(1, BusinessID);
			resultSet = preparedStatement.executeQuery();

			while(resultSet.next())
			{
				Review newReview = new Review(resultSet.getInt(1),
						resultSet.getInt(2), resultSet.getDouble(3), resultSet.getString(4));
				Reviews.add(newReview);
			}
			
			return Reviews;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList<Review> getReviews()
	{
		try
		{
			ArrayList<Review> Reviews = new ArrayList<Review>();
			
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM reviews ORDER BY BusinessID;");
			
			resultSet = preparedStatement.executeQuery();

			while(resultSet.next())
			{
				Review newReview = new Review(resultSet.getInt(1),
						resultSet.getInt(2), resultSet.getDouble(3), resultSet.getString(4));
				Reviews.add(newReview);
			}
			
			return Reviews;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public void insertCategories(int BusinessID, String[] Categories)
	{
		try
	    {
			for (int i = 0; i < Categories.length; i++) 
			{
				int CategoryLookUp = getCategory(Categories[i]);
				if(CategoryLookUp == 0)
				{
					preparedStatement = connect
				            .prepareStatement("insert into categories values (default, ?)");

				        preparedStatement.setString(1, Categories[i]);
				        preparedStatement.executeUpdate();
				}
				insertBusinessCategory(BusinessID, getCategory(Categories[i]));
			}        
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
	}
	
	public int getCategory(String Category)
	{
		try
		{
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM categories WHERE Category = ?;");
			preparedStatement.setString(1, Category);
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next())
			{
				return resultSet.getInt(1);
			}
			else
			{
				return 0;
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return 0;
	}
	
	public void insertBusinessYelpCategory(int BusinessID, String YelpCategory)
	{
		try
	    {
			int YelpCategoryID = getYelpCategoryID(YelpCategory);
			boolean YelpCategoryLookUp = checkBusinessYelpCategory(BusinessID,YelpCategoryID);
			if(YelpCategoryLookUp == false)
			{
				preparedStatement = connect
			            .prepareStatement("insert into business_yelpcategories values (default, ?, ?)");

			        preparedStatement.setInt(1, BusinessID);
			        preparedStatement.setInt(2, YelpCategoryID);
			        
			        preparedStatement.executeUpdate();
			}
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
	}
	
	public boolean checkBusinessYelpCategory(int BusinessID, int YelpCategory)
	{
		try
		{
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM business_yelpcategories WHERE BusinessID = ? AND YelpCategoryID = ?;");
			preparedStatement.setInt(1, BusinessID);
			preparedStatement.setInt(2, YelpCategory);
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return false;
	}
	
	public int getYelpCategoryID(String YelpCategory)
	{
		try
		{
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM yelp_categories WHERE Category = ?;");
			preparedStatement.setString(1, YelpCategory);
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next())
			{
				return resultSet.getInt(1);
			}
			else
			{
				insertYelpCategory(YelpCategory);
				preparedStatement = connect
				        .prepareStatement("SELECT * FROM yelp_categories WHERE Category = ?;");
				preparedStatement.setString(1, YelpCategory);
				resultSet = preparedStatement.executeQuery();
				if(resultSet.next())
				{
					return resultSet.getInt(1);
				}
				else
				{
					return 0;
				}
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return 0;
	}
	
	public void insertYelpCategory(String YelpCategory)
	{
		try
	    {
			preparedStatement = connect
		            .prepareStatement("insert into yelp_categories values (default, ?)");

			preparedStatement.setString(1, YelpCategory);
			preparedStatement.executeUpdate();
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
	}

	public int[] getBusinessCategories(int BusinessID)
	{
		return null;
	}
	
	public void insertBusinessCategory(int BusinessID, int Category)
	{
		try
	    {
			boolean BusinessCategoryLookUp = checkBusinessCategory(BusinessID,Category);
			if(BusinessCategoryLookUp == false)
			{
				preparedStatement = connect
			            .prepareStatement("insert into business_categories values (default, ?, ?)");

		        preparedStatement.setInt(1, BusinessID);
		        preparedStatement.setInt(2, Category);
		        
		        preparedStatement.executeUpdate();
			}
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
	}
	
	public boolean checkBusinessCategory(int BusinessID, int Category)
	{
		try
		{
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM business_categories WHERE BusinessID = ? AND CategoryID = ?;");
			preparedStatement.setInt(1, BusinessID);
			preparedStatement.setInt(2, Category);
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return false;
	}
	
	public void deleteReviews(Business business)
	{
		try
	    {   
			Business BusinessLookUp = getBusiness(business.getBusinessID());
			if(BusinessLookUp != null)
			{
		        preparedStatement = connect
		            .prepareStatement("delete from reviews WHERE BusinessID = ?");
	
		        preparedStatement.setInt(1, business.getID());
		        preparedStatement.executeUpdate();
			}
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
	}
	
	public int reviewsCount(Business business)
	{
		try
	    {   
			Business BusinessLookUp = getBusiness(business.getBusinessID());
			if(BusinessLookUp != null)
			{
		        preparedStatement = connect
		            .prepareStatement("select COUNT(*) from reviews WHERE BusinessID = ?");
	
		        preparedStatement.setInt(1, business.getID());
		        resultSet = preparedStatement.executeQuery();
		        if(resultSet.next())
		        {
		        	return resultSet.getInt(1);
		        }
			}
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
		return 0;
	}
	
	public int reviewsCount(int business)
	{
		try
		{
	        preparedStatement = connect
	            .prepareStatement("select ReviewCount from business WHERE ID = ?");

	        preparedStatement.setInt(1, business);
	        resultSet = preparedStatement.executeQuery();
	        if(resultSet.next())
	        {
	        	return resultSet.getInt(1);
	        }
	        else
	        {
	        	return 0;
	        }
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
		return 0;
	}
	
	public void updateReviewCount(int ReviewCount, Business business)
	{
		try
	    {   
			Business BusinessLookUp = getBusiness(business.getBusinessID());
			if(BusinessLookUp != null)
			{
		        preparedStatement = connect
		            .prepareStatement("update business set ReviewCount = ? WHERE BusinessID = ?");
	
		        preparedStatement.setInt(1, ReviewCount);
		        preparedStatement.setString(2, business.getBusinessID());
		        preparedStatement.executeUpdate();
			}
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
	}
	
	public void insertPreProcessedData(int BusinessID, float Rating, float ProcessedScore, 
											int FamilyWordCount, int FamilyPositive, int FamilyNegative,
											int CoupleWordCount, int CouplePositive, int CoupleNegative,
											int FriendsWordCount, int FriendsPositive, int FriendsNegative)
	{
		try
	    {
			if(getPreProcessedData(BusinessID))
			{
				deletePreProcessedData(BusinessID);
			}
			
			preparedStatement = connect
		            .prepareStatement("insert into preprocessed_data values (default, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

	        preparedStatement.setInt(1, BusinessID);
	        preparedStatement.setFloat(2, Rating);
	        preparedStatement.setInt(3, FamilyWordCount);
	        preparedStatement.setInt(4, FamilyPositive);
	        preparedStatement.setInt(5, FamilyNegative);
	        preparedStatement.setInt(6, CoupleWordCount);
	        preparedStatement.setInt(7, CouplePositive);
	        preparedStatement.setInt(8, CoupleNegative);
	        preparedStatement.setInt(9, FriendsWordCount);
	        preparedStatement.setInt(10, FriendsPositive);
	        preparedStatement.setInt(11, FriendsNegative);
	        preparedStatement.setFloat(12, ProcessedScore);
	        
	        preparedStatement.executeUpdate();
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
	}
	
	public boolean getPreProcessedData(int BusinessID)
	{
		try
		{
			preparedStatement = connect
			        .prepareStatement("SELECT * FROM preprocessed_data WHERE BusinessID = ?;");
			
			preparedStatement.setInt(1, BusinessID);
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return false;
	}
	
	public void deletePreProcessedData(int businessID)
	{
		try
	    {
	        preparedStatement = connect
	            .prepareStatement("delete from preprocessed_data WHERE BusinessID = ?");

	        preparedStatement.setInt(1, businessID);
	        preparedStatement.executeUpdate();
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
	}
}